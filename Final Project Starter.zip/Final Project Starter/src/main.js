import Vue from 'vue'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'

import App from './App.vue'
import { routes } from '/routes.js'
import { store } from './store/store.js'

Vue.use(VueRouter);
Vue.use(VueResource);

Vue.http.options.root =  'https://stock-tr.firebaseio.com/;' //unsure

Vue.filter('currency', (value) => {
  //ToDo: Return value.toLocalString(), Add $ sign before the value
    return $value.toLocaleString(); //unsure
});

const router = new VueRouter({
    mode: 'history',
    //ToDo: Set router mode to history
    //ToDo: Pass routes constant imported from above
});

new Vue({
  el: '#app',
    router,
    store,
    //ToDo: Pass the router constant to vue application
    //ToDo: Pass store constant to vue application,
  render: h => h(App)
});
