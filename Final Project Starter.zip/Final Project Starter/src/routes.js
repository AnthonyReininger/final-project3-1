import Home from './components/Home.vue'
import Portfolio from './components/portfolio/Portfolio.vue'
import Stock from './components/portfolio/Stock.vue'
import Stock from './components/stocks/Stock.vue'
import Stocks from './components/stocks/Stocks.vue'

export const routes = [
    {path: '/', name: 'Home'},
    {path: '/components/portfolio/Portfolio.vue', name: 'Portfolio'},
    {path: '/components/stocks/Stocks.vue', name: 'Stocks'}

    //ToDo: Create Route for Home Component with root (/) path
    //ToDo: Create Route for Portfolio Component
    //ToDo: Create Route for Stocks Component
];