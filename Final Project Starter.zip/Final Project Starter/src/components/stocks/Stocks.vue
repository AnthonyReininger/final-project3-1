<template>
    <div>
        <!--ToDo: Load app-stock component-->
            <!--ToDo: Loop through stock in stocks using v-for-->
            <!--ToDo: Bind to stock using : and pass stock from the v-for-->
    </div>
</template>

<script>
    //ToDo: Import Stock from ./Stock.vue

    export default {
        //ToDo: Initialize Stock component and name it appStock

        computed: {
            //ToDo: Create stocks computer method
                // ToDo: Return $store.getters.stocks
        }
    }
</script>